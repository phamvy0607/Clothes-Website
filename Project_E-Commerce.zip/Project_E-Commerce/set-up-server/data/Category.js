const categorys = [
  {
    name: "trousers",
  },
  {
    name: "shirt",
  },
];

export default categorys;
