const vouches = [
  {
    name: "Giam 1$",
    discount: 1,
    image: "img01.png",
  },
  {
    name: "Giam 5$",
    discount: 5,
    image: "img02.png",
  },
  {
    name: "Giam 10$",
    discount: 10,
    image: "img03.png",
  },
];

export default vouches;
