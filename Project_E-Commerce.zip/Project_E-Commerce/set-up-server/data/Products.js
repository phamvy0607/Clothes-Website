const products = [
  {
    name: "Veraaaaa",
    description: "Aaaaa",
    price: 1,
    countInStock: 2,
    rating: 3,
    numReviews: 4,
    images: ["img01.png", "img02.png", "img03.png"],
    category: "shirt",
  },
  {
    name: "Veraaaaa1",
    description: "Aaaaa",
    price: 2,
    countInStock: 5,
    rating: 1,
    numReviews: 4,
    images: ["img02.png", "img03.png", "img04.png"],
    category: "trousers",
  },
];

export default products;
