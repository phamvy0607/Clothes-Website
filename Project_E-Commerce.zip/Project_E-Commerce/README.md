# Project Fashion shop

Has two folder includes Project_E-commerce

## Deployment

To deploy this project must into cd frontEnd

```bash
  npm start
```

To deploy server must into cd set-up-server

```bash
  npm run server
```
