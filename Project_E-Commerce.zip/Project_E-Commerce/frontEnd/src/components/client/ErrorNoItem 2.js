import React from 'react'

export default function ErrorNoItem({src}) {
  return (
    <img style={{width : "50%" , marginLeft : "25%"}}
      src={src}
      alt="error"
    />
  )
}
