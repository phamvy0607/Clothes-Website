export const URL_BASE = "http://localhost:8000/"
export const URL_SEARCH = "http://localhost:8000/listProduct?name_like="