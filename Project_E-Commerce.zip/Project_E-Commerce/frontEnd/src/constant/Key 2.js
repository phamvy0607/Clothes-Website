export const KEY_GOOGLEMAP = 'AIzaSyAjED1nqiq5mxLr0yrnri1C5QxbAcX3KNI'
export const CAM_LE = [
    "Hòa An",
    "Hòa Phát",
    "Hòa Thọ Đông",
    "Hòa Thọ Tây",
    "Hòa Xuân",
    "Khuê Trung",
  ]
 export const HAI_CHAU = [
    "Bình Hiên",
    "Bình Thuận",
    "Hải Châu I",
    "Hải Châu II",
    "Hòa Cường Bắc",
    "Hòa Cường Nam",
    "Hòa Thuận Đông",
    "Hòa Thuận Tây",
    "Nam Dương",
    "Phước Ninh",
    "Thạch Thang",
    "Thanh Bình",
    "Thuận Phước",
  ];
 export const LIEN_CHIEU = [
    "Hòa Hiệp Bắc",
    "Hòa Minh",
    "Hòa Hiệp Nam",
    "Hòa Khánh Bắc",
    "Hòa Khánh Nam",
  ];
 export const NGU_HANH_SON = ["Hòa Hải", "Hòa Quý", "Khuê Mỹ", "Mỹ An"];

 export const SON_TRA = [
    "An Hải Bắc",
    "An Hải Đông",
    "An Hải Tây",
    "Mân Thái",
    "Nại Hiên Đông",
    "Phước Mỹ",
  ];
 export const THANH_KHE = ['An Khê',
    'Chính Gián',
    'Hòa Khê',
    'Tam Thuận',
    'Tân Chính',
    'Thạc Gián',
    'Thanh Khê Đông',
    'Thanh Khê Tây',
    'Vĩnh Trung']
   export const HOA_VANG = ['Hòa Phong',
      'Hòa Bắc',
      'Hòa Châu',
      'Hòa Khương',
      'Hòa Liên',
      'Hòa Nhơn',
      'Hòa Ninh',
      'Hòa Phú',
      'Hòa Phước',
      'Hòa Sơn',
      'Hòa Tiến']
      export const QUAN = [
          'Hải Châu','Cẩm Lệ','Thanh Khê','Liên Chiểu','Ngũ Hành Sơn','Sơn Trà','Hòa Vang'
      ]