
export const REGEX_PASSWORD= /^(?=.*\d)(?=.*[a-zA-Z])[\da-zA-Z_.\-@]{8,}$/
export const REGEX_ONLY_NUMBER= /(84|0[3|5|7|8|9])+([0-9]{8})\b/
export const REGEX_ONLY_NUMBER_v2= /([0-9]{8})\b/
