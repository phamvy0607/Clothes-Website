export const STATUS_CODE = {
    SUCCESS : 200,
    CREATED : 201,
    UPDATE : 202,
    ERROR : 404
}