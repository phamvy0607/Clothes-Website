import { CHANGE_BACKGROUND } from "./Types"

export const changeBgRequest = () => {
    return {
        type : CHANGE_BACKGROUND,
        payload : ''
    }
}