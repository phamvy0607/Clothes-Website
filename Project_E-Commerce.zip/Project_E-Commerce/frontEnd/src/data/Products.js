const products = [
  {
    _id: "1",
    name: "Veraaaaa",
    image: "/images/img01.png",
    description: "Aaaaa",
    price: 10,
    countInStock: 2,
    rating: 3,
    numReviews: 4,
  },
  {
    _id: "2",
    name: "Veraaaaa",
    image: "/images/img02.png",
    description: "Aaaaa",
    price: 11,
    countInStock: 5,
    rating: 1,
    numReviews: 4,
  },
];

export default products;
