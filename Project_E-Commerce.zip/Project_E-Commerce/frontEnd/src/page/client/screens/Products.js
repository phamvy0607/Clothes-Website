import React from 'react'
import CategoryCommon from '../../../components/client/CategoryCommon'

export default function Products() {
  return (
    <CategoryCommon limit={16}/>
  )
}
