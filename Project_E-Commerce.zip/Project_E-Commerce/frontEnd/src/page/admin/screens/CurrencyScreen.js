import React from "react";
import CurrencyComponent from "../../../components/admin/currency/currencyComponent";

const CurrencyScreen = () => {
  return (
    <>
      <CurrencyComponent />
    </>
  );
};

export default CurrencyScreen;
