import React from "react";
import AddProductMain from "./../../../components/admin/products/AddProductMain";
const AddProducts = () => {
  return (
    <>
      <AddProductMain />
    </>
  );
};

export default AddProducts;
