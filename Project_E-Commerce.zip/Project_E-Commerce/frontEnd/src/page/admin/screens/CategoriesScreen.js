import React from "react";
import MainCategories from "./../../../components/admin/Categories/MainCategories";
const CategoriesScreen = () => {
  return (
    <>
      <MainCategories />
    </>
  );
};

export default CategoriesScreen;
