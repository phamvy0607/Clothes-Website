import React from "react";
import CommentsTables from "../../../components/admin/Comments/Comments";
const ProductComments = () => {
  return (
    <>
      <CommentsTables />
    </>
  );
};

export default ProductComments;
