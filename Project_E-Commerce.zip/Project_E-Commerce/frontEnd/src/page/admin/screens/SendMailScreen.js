import React from "react";
import { ContactUs } from "../../../components/admin/users/contactEmail/ContactUs";

const UsersScreen = () => {
  return (
    <>
      <ContactUs />
    </>
  );
};

export default UsersScreen;
