import React from "react";

import Main from "./../../../components/admin/Home/main";

const HomeScreen = () => {
  return (
    <>
      <Main />
    </>
  );
};

export default HomeScreen;
