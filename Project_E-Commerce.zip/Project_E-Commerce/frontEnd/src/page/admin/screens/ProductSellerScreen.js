import React from "react";
import ProductSeller from "../../../components/admin/productSeller/ProductSeller";

const ProductSellerScreen = () => {
  return (
    <>
      <ProductSeller />
    </>
  );
};

export default ProductSellerScreen;
