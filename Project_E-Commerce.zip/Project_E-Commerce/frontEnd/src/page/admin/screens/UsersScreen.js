import React from "react";

import UserComponent from "./../../../components/admin/users/UserComponent";
const UsersScreen = () => {
  return (
    <>
      <UserComponent />
    </>
  );
};

export default UsersScreen;
